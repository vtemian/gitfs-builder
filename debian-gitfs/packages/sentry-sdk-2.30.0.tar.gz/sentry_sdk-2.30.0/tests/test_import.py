# As long as this file can be imported, we are good.
from sentry_sdk import *  # noqa: F403, F401


def test_import():
    # As long as this file can be imported, we are good.
    assert True

Friends of pygit2:

- Add your name to the list,
  [become a friend of pygit2](https://github.com/sponsors/jdavid).

Past sponsors:

- [Microsoft](https://github.com/microsoft)
- [Iterative](https://iterative.ai/)
- [SourceHut](https://sourcehut.org)
- [GitHub](https://github.com/github)
- [omniproc](https://github.com/omniproc)
